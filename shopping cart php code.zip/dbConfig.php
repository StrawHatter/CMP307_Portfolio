<?php
//connect to the database - error message if not
$dbHost = 'localhost';
$dbUsername = 'sql1605667';
$dbPassword = 'Georgie0462';
$dbName = 'sql1605667';
//Create connection to the database
$db = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
if ($db->connect_error) {die("Unable to connect database: " . $db->connect_error);
} 
?>